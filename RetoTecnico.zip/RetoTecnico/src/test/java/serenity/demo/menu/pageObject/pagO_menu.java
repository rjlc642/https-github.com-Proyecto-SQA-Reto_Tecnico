package serenity.demo.menu.pageObject;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.screenplay.targets.Target;

public class pagO_menu {
    public  static final Target span_Recruitment = Target.the("opción menu Recruitment").located(By.xpath("//*[text()='Recruitment']"));

}
